import { uploads } from "./uploads";

export const schema = {
  uploads,
};
